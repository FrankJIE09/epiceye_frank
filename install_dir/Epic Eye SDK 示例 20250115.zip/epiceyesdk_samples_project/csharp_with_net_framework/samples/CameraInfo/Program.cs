﻿using System.ComponentModel;
using System;
using System.Collections.Generic;
using TFTech;
using TFTech.Data;

namespace EpicEye3.SDK.Example {
    public class Program {
        public static void Main(string[] args) {
            Console.WriteLine("----------------Searching Camera----------------");
            List<EpicEyeInfo> epicEyeList = EpicEye.SearchCamera();
            foreach (EpicEyeInfo item in epicEyeList) {
                Console.WriteLine("SN: " + item.SN + "  IP: " + item.IP + "  别名: " + item.Alias);
            }

            Console.WriteLine("-----------------GetInfo----------------");
            foreach (EpicEyeInfo item in epicEyeList) {
                EpicEyeInfo info = EpicEye.GetInfo(item.IP);
                Console.WriteLine($"CameraIP: {item.IP}");
                foreach (PropertyDescriptor descriptor in TypeDescriptor.GetProperties(info)) {
                    Console.WriteLine("{0}: {1}", descriptor.Name, descriptor.GetValue(info));
                }
            }
        }
    }
}