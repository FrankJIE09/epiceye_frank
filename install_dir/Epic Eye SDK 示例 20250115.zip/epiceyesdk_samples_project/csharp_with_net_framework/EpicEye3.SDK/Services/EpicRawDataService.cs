using TFTech.Data;
using DU = TFTech.Utils.DataUtils;
using System;
using System.Linq;
using System.Threading.Tasks;
using System.IO;

namespace TFTech.Services {
    internal class EpicRawDataService {
        public const int EpicRaw1HeaderSize = 168;
        public const int EpicRaw2HeaderSize = 40;
        public static T DecodeEpicRawHeader<T>(byte[] rawData) {
            int size = DU.GetSizeOfStruct<T>();
            return DU.BytesToStruct<T>(rawData.Take(size).ToArray());
        }

        public static (int height, int width) GetShapeFromEpicRaw(byte[] rawData) {
            string fileType = GetFileType(rawData);
            switch (fileType) {
                case "EPICRAW1":
                    EpicRawHeader1 header1 = DecodeEpicRawHeader<EpicRawHeader1>(rawData);
                    if (header1 is null) {
                        return (-1, -1);
                    }
                    return (header1.Height, header1.Width);
                case "EPICRAW2":
                    EpicRawHeader2 header2 = DecodeEpicRawHeader<EpicRawHeader2>(rawData);
                    if (header2 is null) {
                        return (-1, -1);
                    }
                    return (header2.Height, header2.Width);
                default:
                    if ((char)fileType[7] == 0) {
                        goto case "EPICRAW1";
                    }
                    Console.WriteLine("Unsupport type!");
                    return (-1, -1);
            }
        }

        public static byte[] DecodeImageFromEpicRaw(byte[] rawData) {
            string fileType = GetFileType(rawData);
            switch (fileType) {
                case "EPICRAW1":
                    EpicRawHeader1 header1 = DecodeEpicRawHeader<EpicRawHeader1>(rawData);
                    if (header1 is null) {
                        return null;
                    }
                    return rawData.Skip(EpicRaw1HeaderSize + header1.DepthDataLength).Take(header1.ColorDataLength).ToArray();
                case "EPICRAW2":
                    EpicRawHeader2 header2 = DecodeEpicRawHeader<EpicRawHeader2>(rawData);
                    if (header2 is null) {
                        return null;
                    }
                    return rawData.Skip(
                        EpicRaw2HeaderSize +
                        header2.CameraMatrixLength +
                        header2.DistortionLength +
                        header2.ConfigStrLength +
                        header2.DepthDataLength
                    ).Take(header2.ImageDataLength).ToArray();
                default:
                    if ((char)fileType[7] == 0) {
                        goto case "EPICRAW1";
                    }
                    Console.WriteLine("Unsupport type!");
                    return null;
            }
        }

        public static byte[] DecodePointCloudFromEpicRaw(byte[] rawData, byte[] undistortLut = null) {
            if(rawData == null){
                return null;
            }
            string fileType = GetFileType(rawData);
            byte[] depthData = GetDepthFromEpicRaw(rawData, fileType);
            if (depthData is null) {
                return null;
            }
            switch (fileType) {
                case "EPICRAW1":
                    EpicRawHeader1 header1 = DecodeEpicRawHeader<EpicRawHeader1>(rawData);
                    if (header1 is null) {
                        return null;
                    }
                    return DecodePointCloudFromDepth(depthData, header1.CameraMatrix, header1.Width, header1.Height, undistortLut);

                case "EPICRAW2":
                    EpicRawHeader2 header2 = DecodeEpicRawHeader<EpicRawHeader2>(rawData);
                    if (header2 is null) {
                        return null;
                    }
                    Matrix3x3 cameraMatrix = DU.BytesToStruct<Matrix3x3>(
                        rawData.Skip(EpicRaw2HeaderSize).Take(header2.CameraMatrixLength).ToArray()
                    );
                    if (cameraMatrix is null) {
                        return null;
                    }
                    return DecodePointCloudFromDepth(depthData, cameraMatrix, header2.Width, header2.Height, undistortLut);
                default:
                    if ((char)fileType[7] == 0) {
                        goto case "EPICRAW1";
                    }
                    Console.WriteLine("Unsupport type!");
                    return null;
            }
        }

        public static byte[] GetDepthFromEpicRaw(byte[] rawData, string fileType = null) {
            if (string.IsNullOrEmpty(fileType)) {
                fileType = GetFileType(rawData);
            }
            switch (fileType) {
                case "EPICRAW1":
                    EpicRawHeader1 header1 = DecodeEpicRawHeader<EpicRawHeader1>(rawData);
                    if (header1 is null) {
                        return null;
                    }
                    return rawData.Skip(EpicRaw1HeaderSize).Take(header1.DepthDataLength).ToArray();
                case "EPICRAW2":
                    EpicRawHeader2 header2 = DecodeEpicRawHeader<EpicRawHeader2>(rawData);
                    if (header2 is null) {
                        return null;
                    }
                    return rawData.Skip(
                        EpicRaw2HeaderSize +
                        header2.CameraMatrixLength +
                        header2.DistortionLength +
                        header2.ConfigStrLength
                    ).Take(header2.DepthDataLength).ToArray();
                default:
                    if ((char)fileType[7] == 0) {
                        goto case "EPICRAW1";
                    }
                    Console.WriteLine("Unsupport type!");
                    return null;
            }
        }

        public static byte[] DecodePointCloudFromDepth(byte[] depthData, Matrix3x3 cameraMatrix, int width, int height, byte[] undistortLut = null) {
            MemoryStream memoryStream = new MemoryStream();
            for (int i = 0; i < height; i++)
            {
                for (int j = 0; j < width; j++)
                {
                    int p = Convert.ToInt32((width * i + j) * 4);
                    float Z = BitConverter.ToSingle(depthData, p);
                    float X = 0;
                    float Y = 0;
                    if (Z > 0.1 && Z < 6000.0)
                    {
                        float u = j;
                        float v = i;
                        if (undistortLut != null && undistortLut.Length > 0)
                        {
                            u = BitConverter.ToSingle(undistortLut, (j + i * width) * 4 * 2);
                            v = BitConverter.ToSingle(undistortLut, (j + i * width) * 4 * 2 + 4);
                        }
                        X = (float)(Z * (u - cameraMatrix.M02) / cameraMatrix.M00);
                        Y = (float)(Z * (v - cameraMatrix.M12) / cameraMatrix.M11);
                    }
                    else
                    {
                        Z = float.NaN;
                    }
                    memoryStream.Write(BitConverter.GetBytes(X), 0, 4);
                    memoryStream.Write(BitConverter.GetBytes(Y), 0, 4);
                    memoryStream.Write(BitConverter.GetBytes(Z), 0, 4);
                }
            }
            return memoryStream.ToArray();
        }

        private static string GetFileType(byte[] rawData) {
            return System.Text.Encoding.ASCII.GetString(rawData, 0, 8);
        }
    }
}