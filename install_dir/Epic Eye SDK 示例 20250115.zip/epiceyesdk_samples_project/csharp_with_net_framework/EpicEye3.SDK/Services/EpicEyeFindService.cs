using System.Net;
using System.Net.Sockets;
using System.Text;
using TFTech.Data;
using System.Collections.Generic;
using System.Threading;
using System.Linq;
using System;

namespace TFTech.Services {
    public class EpicEyeFindService {
        private static bool _isRun = false;
        private static IPEndPoint _udpClientIp = new IPEndPoint(IPAddress.Parse("0.0.0.0"), 5665);
        private static List<int> _portList = new List<int> {5665, 5666, 5667, 5668};
        private static UdpClient _udpClient = null;
        private static Thread _udpClientThread = null;
        private static List<EpicEyeInfo> _eyeList = new List<EpicEyeInfo>();

        /// <summary>
        /// 启动
        /// </summary>
        public static void Start() {
            _isRun = true;
            foreach (int port in _portList) {
                _udpClientIp = new IPEndPoint(IPAddress.Parse("0.0.0.0"), port);
                try {
                    Console.WriteLine($"尝试侦听端口{port}...");
                    _udpClient = new UdpClient(_udpClientIp);
                    Console.WriteLine($"侦听端口{port}成功！");
                    break;
                } catch (Exception e) {
                    Console.WriteLine($"侦听端口{port}失败！{e.Message}");
                }
            }
            if(_udpClient == null) {
                throw new System.Exception("相机发现服务端口异常，检查端口是否被占用！");
            }
            if (_udpClientThread == null) {
                _udpClientThread = new Thread(UdpReceive);
                _udpClientThread.Start();
            }
        }

        /// <summary>
        /// 停止
        /// </summary>
        public static void Stop() {
            _isRun = false;
            _udpClient?.Close();
        }

        /// <summary>
        /// 释放
        /// </summary>
        public static void Dispose() {
            _isRun = false;
            _udpClientThread?.Abort();
            while (_udpClientThread?.ThreadState != ThreadState.Aborted) {
                Thread.Sleep(100);
            }
            _udpClient?.Close();
        }

        /// <summary>
        /// 获取发现相机列表
        /// </summary>
        /// <returns></returns>
        public static List<EpicEyeInfo> GetEyeList() {
            return _eyeList;
        }

        /// <summary>
        /// 清除发现相机列表
        /// </summary>
        /// <returns></returns>
        public static List<EpicEyeInfo> ClearEyeList() {
            _eyeList.Clear();
            return _eyeList;
        }
        public delegate void EyeListHandler();
        public static event EyeListHandler EyeListEvent;
        private static void UdpReceive() {
            while (true) {
                if (!_isRun || _udpClient == null) {
                    Thread.Sleep(1000);
                    continue;
                }
                byte[] data = _udpClient.Receive(ref _udpClientIp);
                if (data.Length <= 0) {
                    continue;
                }
                EpicEyeInfo epicEyeInfo = Newtonsoft.Json.JsonConvert.DeserializeObject<EpicEyeInfo>(Encoding.UTF8.GetString(data));
                if (epicEyeInfo == null || epicEyeInfo.IP == null) {
                    continue;
                }
                if (epicEyeInfo.IP.Contains(":")) {
                    //New
                    string[] strs = epicEyeInfo.IP.Split(':');
                    if (string.IsNullOrEmpty(strs[0]) || strs[0] == "127.0.0.1")
                        epicEyeInfo.IP = _udpClientIp.Address.ToString() + ":" + strs[1];
                } else {
                    //Old
                    if (string.IsNullOrEmpty(epicEyeInfo.IP)) {
                        epicEyeInfo.IP = _udpClientIp.Address.ToString() + ":5000";
                    }
                    if (!epicEyeInfo.IP.Contains(":")) {
                        epicEyeInfo.IP += ":5000";
                    }
                }
                EpicEyeInfo firstEpicEyeInfo = _eyeList.Where(x => x.IP == epicEyeInfo.IP).FirstOrDefault();
                if (firstEpicEyeInfo == null) {
                    _eyeList.Add(epicEyeInfo);
                    if (EyeListEvent != null) {
                        EyeListEvent();
                    }
                } else {
                    firstEpicEyeInfo = epicEyeInfo;
                }
                Thread.Sleep(100);
            }
        }
    }
}