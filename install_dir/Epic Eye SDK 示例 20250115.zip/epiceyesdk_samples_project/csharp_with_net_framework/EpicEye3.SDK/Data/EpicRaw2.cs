using System.Runtime.InteropServices;
using System.Text;

namespace TFTech.Data {
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class EpicRaw2 {
        public EpicRawHeader2 Header { get; set; } = new EpicRawHeader2();
        public byte[] Data { get; set; }
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public class EpicRawHeader2 {                       // 40 bytes in total
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public byte[] FileType = Encoding.Default.GetBytes("EPICRAW2");      // 8 bytes
        public int Width { get; set; }                  // 4 bytes
        public int Height { get; set; }                 // 4 bytes
        public int DataType { get; set; }               // 4 bytes
        public int CameraMatrixLength { get; set; }     // 4 bytes
        public int DistortionLength { get; set; }       // 4 bytes
        public int ConfigStrLength { get; set; }        // 4 bytes
        public int DepthDataLength { get; set; } = 1;   // 4 bytes
        public int ImageDataLength { get; set; } = 1;   // 4 bytes
    }
}