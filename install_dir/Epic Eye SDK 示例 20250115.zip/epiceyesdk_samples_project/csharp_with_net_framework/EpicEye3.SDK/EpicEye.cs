using System.Collections;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System;
using RestSharp;
using TFTech.Data;
using TFTech.Services;

namespace TFTech {
    public partial class EpicEye {
        private static string _SDKVersion = "3.4.0";

        private static string _baseUrl = "http://{0}/api/";

        private static readonly Dictionary<string, string> _requestPaths = new Dictionary<string, string>() {
            {"GetInfo"  ,      "EpicEye/Info"},
            {"SetConfig",      "CameraConfig"},
            {"GetConfig",      "CameraConfig?frameId={0}"},
            {"GetHeader",      "Frame/Header?frameId={0}"},
            {"TriggerCapture", "Frame?pointCloud={0}"},
            {"EpicRaw",        "Frame?frameId={0}"},
            {"Depth",          "Depth?frameId={0}"},
            {"Ply",            "PointCloud/PLY?frameId={0}"},
            {"UndistortLut",   "UndistortLut"},
            {"CameraMatrix",   "CameraParameters/Intrinsic/CameraMatrix"},
            {"Distortion",     "CameraParameters/Intrinsic/Distortion"},
        };

        private static Hashtable _undistortLutHT = new Hashtable();

        public static string GetSDKVersion() {
            return _SDKVersion;
        }

        /// <summary>method
        /// <c>GetHeader</c> 获取相机照片信息.
        /// </summary>
        /// <param ip="ip"> 相机的IP地址 </param>
        /// <param name="frameId"> 相机的frameId </param>
        /// <returns> EpicRawHeader, 相机的照片信息,包含width，height </returns>
        public static string GetHeader(string ip, string frameId, int timeout=2000) {
            if (string.IsNullOrEmpty(ip)) {
                return null;
            }
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            var response = restClient.Get(
                new RestRequest(string.Format(_requestPaths["GetHeader"]) + frameId)
            );
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return null;
            }
            return response.Content;
        }

        /// <summary>method 
        /// <c>GetInfo</c> 获取相机信息.
        /// </summary>
        /// <param name="ip"> 相机的ip地址 </param> 
        /// <returns> EpicEyeInfo, 相机的详细信息,包含width，height </returns>
        public static EpicEyeInfo GetInfo(string ip, int timeout=2000) {
            if (string.IsNullOrEmpty(ip)) {
                return null;
            }
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            var response = restClient.Get(
                new RestRequest(_requestPaths["GetInfo"])
            );
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return null;
            }
            return Newtonsoft.Json.JsonConvert.DeserializeObject<EpicEyeInfo>(response.Content);
        }

        /// <summary>method  
        /// <c>TriggerFrame</c> 触发拍摄一个Frame，一个Frame可能同时包含
        ///                     2D图像和点云数据，通过frameID进行索引，调用此方法后，会返回frameID，
        ///                     随后可以通过getImage和getPointCloud方法将数据取回
        /// </summary>
        /// <param name="ip"> 相机的ip地址 </param>
        /// <param name="withPointCloud"> 表示是否请求点云数据，如果设为false，则此次触发的Frame仅包含2D图像数 </param> 
        /// <returns> EpicEyeInfo, 相机的详细信息,包含width，height </returns>
        public static string TriggerCapture(string ip, bool withPointCloud = true, int timeout=2000) {
            if (string.IsNullOrEmpty(ip)) {
                return null;
            }
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            var response = restClient.Post<string>(
                new RestRequest(string.Format(_requestPaths["TriggerCapture"], withPointCloud))
            );
            return response.Data;
        }

        private static byte[] GetUndistortLut(string ip, int timeout=15000) {
            if (string.IsNullOrEmpty(ip)) {
                return null;
            }
            if (_undistortLutHT.ContainsKey(ip)) {
                return (byte[])_undistortLutHT[ip];
            }
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            var response = restClient.Get(
                new RestRequest(string.Format(_requestPaths["UndistortLut"]))
            );
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return null;
            }
            byte[] bytes = response.RawBytes;
            if (bytes != null && bytes.Length > 0) {
                _undistortLutHT.Add(ip, bytes);
            } else {
                _undistortLutHT.Add(ip, null);
            }
            return bytes;
        }

        /// <summary>method 
        /// <c>GetPointCloud</c> 根据frameID获取点云.
        /// </summary>
        /// <param name="ip"> 相机的ip地址 </param> 
        /// <param name="frameId"> 待获取数据的frameID，可由triggerFrame获得 </param>
        /// <returns> byte[], 返回的以byte数组形式存储的点云数据， 注意需要转换成float类型的数组后才可以进行访问 </returns>
        public static byte[] GetPointCloud(string ip, string frameId, int timeout=15000) {
            
            double networkTransmitTimeMs = 0;
            double networkSpeedMbps = 0;
            return GetPointCloudWithTimeStats(ip, frameId, ref networkTransmitTimeMs, ref networkSpeedMbps, timeout);
        }


        /// <summary>method 
        /// <c>GetPointCloud</c> 根据frameID获取点云.
        /// </summary>
        /// <param name="ip"> 相机的ip地址 </param> 
        /// <param name="frameId"> 待获取数据的frameID，可由triggerFrame获得 </param>
        /// <param name="networkTransmitTimeMs">返回的网络传输时间，单位:ms </param>
        /// <param name="networkSpeedMbps">使用当前帧测得的网速，单位:Mbps </param>
        /// <returns> byte[], 返回的以byte数组形式存储的点云数据， 注意需要转换成float类型的数组后才可以进行访问 </returns>
        public static byte[] GetPointCloudWithTimeStats(string ip, string frameId,
                                                         ref double networkTransmitTimeMs, 
                                                         ref double networkSpeedMbps,
                                                         int timeout=15000) {
            if (string.IsNullOrEmpty(ip)) {
                return null;
            }
            byte[] data = new byte[]{};
            double networkSpeedMbps_ = 0;
            double networkTransmitTimeMs_ = 0;
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            var request = new RestRequest(string.Format(_requestPaths["Depth"], frameId), Method.GET);

            request.AdvancedResponseWriter = (stream, responseIn) => {
                var watch = new System.Diagnostics.Stopwatch();
                var memoryStream = new MemoryStream();
                var buffer = new byte[1024*128];
                long totalCount = 0;
                int bytesRead;
                watch.Start();
                while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) > 0)
                {
                    totalCount += bytesRead;
                    memoryStream.Write(buffer, 0, bytesRead);
                }
                watch.Stop();
                double elapsedSeconds = watch.ElapsedTicks / (System.Diagnostics.Stopwatch.Frequency * 1.0);
                networkTransmitTimeMs_ = elapsedSeconds * 1000L;
                networkSpeedMbps_ = responseIn.ContentLength / elapsedSeconds / 1024L / 1024L * 8;
                data = memoryStream.ToArray();
            };

            var response = restClient.Execute(request);
            networkTransmitTimeMs = networkTransmitTimeMs_;
            networkSpeedMbps = networkSpeedMbps_;
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return null;
            }
            byte[] undistortLut = GetUndistortLut(ip);
            return EpicRawDataService.DecodePointCloudFromEpicRaw(data, undistortLut);
        }

        /// <summary>method 
        /// <c>GetDepth</c> 根据frameID获取深度图.
        /// </summary>
        /// <param name="ip">相机的ip地址 </param>
        /// <param name="frameId">待获取数据的frameID，可由triggerFrame获得</param>
        /// <returns>byte[], 返回的以byte数组形式存储的深度数据， 注意需要转换成float类型的数组后才可以进行访问</returns>
        public static byte[] GetDepth(string ip, string frameId, int timeout=15000) {
            double networkTransmitTimeMs = 0;
            double networkSpeedMbps = 0;
            return GetDepthWithTimeStats(ip, frameId, ref networkTransmitTimeMs, ref networkSpeedMbps, timeout);
        }

        /// <summary>method 
        /// <c>GetDepth</c> 根据frameID获取深度图.
        /// </summary>
        /// <param name="ip">相机的ip地址 </param>
        /// <param name="frameId">待获取数据的frameID，可由triggerFrame获得</param>
        /// <param name="networkTransmitTimeMs">返回的网络传输时间，单位:ms </param>
        /// <param name="networkSpeedMbps">使用当前帧测得的网速，单位:Mbps </param>
        /// <returns>byte[], 返回的以byte数组形式存储的深度数据， 注意需要转换成float类型的数组后才可以进行访问</returns>
        public static byte[] GetDepthWithTimeStats(string ip, string frameId, 
                                                    ref double networkTransmitTimeMs, 
                                                    ref double networkSpeedMbps,
                                                    int timeout=15000) {
            if (string.IsNullOrEmpty(ip)) {
                return null;
            }
            byte[] data = new byte[]{};
            double networkSpeedMbps_ = 0;
            double networkTransmitTimeMs_ = 0;
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            var request = new RestRequest(string.Format(_requestPaths["Depth"], frameId), Method.GET);

            request.AdvancedResponseWriter = (stream, responseIn) => {
                var watch = new System.Diagnostics.Stopwatch();
                var memoryStream = new MemoryStream();
                var buffer = new byte[1024*128];
                long totalCount = 0;
                int bytesRead;
                watch.Start();
                while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) > 0)
                {
                    totalCount += bytesRead;
                    memoryStream.Write(buffer, 0, bytesRead);
                }
                watch.Stop();
                double elapsedSeconds = watch.ElapsedTicks / (System.Diagnostics.Stopwatch.Frequency * 1.0);
                networkTransmitTimeMs_ = elapsedSeconds * 1000L;
                networkSpeedMbps_ = responseIn.ContentLength / elapsedSeconds / 1024L / 1024L * 8;
                data = memoryStream.ToArray();
            };

            var response = restClient.Execute(request);
            networkTransmitTimeMs = networkTransmitTimeMs_;
            networkSpeedMbps = networkSpeedMbps_;
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return null;
            }
            return EpicRawDataService.GetDepthFromEpicRaw(data);
        }

        public static byte[] GetImage(string ip, string frameId, int timeout=15000) {
            if (string.IsNullOrEmpty(ip)) {
                return null;
            }
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            var response = restClient.Get(
                new RestRequest(string.Format(_requestPaths["EpicRaw"], frameId))
            );
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return null;
            }
            byte[] data = response.RawBytes;
            return EpicRawDataService.DecodeImageFromEpicRaw(data);
        }

        /// <summary>method 
        /// <c>GetConfig</c> 根据frameID获取相机参数配置，如果frameID为空字符串""，则返回当前最新的相机配置参数.
        /// </summary>
        /// <param name="ip">相机的ip地址 </param> 
        /// <param name="frameId">待获取数据的frameID，可由triggerFrame获得</param>
        /// <returns>EpicEyeConfig, 返回的相机配置数据</returns>
        public static Hashtable GetConfig(string ip, string frameId = "", int timeout=2000) {
            if (string.IsNullOrEmpty(ip)) {
                return null;
            }
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            var response = restClient.Get(
                new RestRequest(string.Format(_requestPaths["GetConfig"], frameId))
            );
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return null;
            }
            var configObject = Newtonsoft.Json.JsonConvert.DeserializeObject(response.Content.ToString());
            Hashtable configMap = Newtonsoft.Json.JsonConvert.DeserializeObject<Hashtable>(configObject.ToString());
            return configMap;
        }

        /// <summary>method 
        /// <c>SetConfig</c> 更新相机参数配置.
        /// </summary>
        /// <param name="ip">相机的ip地址 </param>
        /// <param name="config">待设置的相机配置数据</param>
        /// <returns>bool,是否请求成功</returns>
        public static bool SetConfig(string ip, Hashtable config, int timeout=2000) {
            if (string.IsNullOrEmpty(ip)) {
                return false;
            }
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            var response = restClient.Put(
                new RestRequest(_requestPaths["SetConfig"]).AddJsonBody(Newtonsoft.Json.JsonConvert.SerializeObject(config))
            );
            Console.WriteLine(response.ErrorMessage);
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return false;
            }
            return true;
        }

        /// <summary>method 
        /// <c>GetCameraMatrix</c> 获取2D图像对应相机的相机矩阵.
        /// </summary>
        /// <param name="ip">相机的ip地址 </param> 
        /// <returns>float[],按行存储的相机矩阵，可恢复成3x3的camera matrix，与OpenCV兼容</returns>
        public static float[] GetCameraMatrix(string ip, int timeout=2000) {
            if (string.IsNullOrEmpty(ip)) {
                return null;
            }
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            var response = restClient.Get(
                new RestRequest(_requestPaths["CameraMatrix"])
            );
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return null;
            }
            return Newtonsoft.Json.JsonConvert.DeserializeObject<float[]>(response.Content);
        }

        /// <summary>method 
        /// <c>GetDistortion</c> 获取2D图像对应相机的畸变参数.
        /// </summary>
        /// <param name="ip">相机的ip地址 </param>
        /// <returns>float[], 相机的畸变参数，和OpenCV兼容</returns>
        public static float[] GetDistortion(string ip, int timeout=2000) {
            if (string.IsNullOrEmpty(ip)) {
                return null;
            }
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            var response = restClient.Get(
                new RestRequest(_requestPaths["Distortion"])
            );
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return null;
            }
            return Newtonsoft.Json.JsonConvert.DeserializeObject<float[]>(response.Content);
        }

        /// <summary>
        /// 获取EpicRaw字节数据
        /// </summary>
        public static byte[] GetFrameInEpicRaw(string ip, string frameId, int timeout=15000) {
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            var response = restClient.Get(
                new RestRequest(string.Format(_requestPaths["EpicRaw"], frameId))
            );
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return null;
            }
            return response.RawBytes;
        }

        /// <summary>method 
        /// <c>GetPointCloudAndImageWithTimeStats</c> 根据frameID获取点云.
        /// </summary>
        /// <param name="ip"> 相机的ip地址 </param> 
        /// <param name="frameId"> 待获取数据的frameID，可由triggerFrame获得 </param>
        /// <param name="networkTransmitTimeMs">返回的网络传输时间，单位:ms </param>
        /// <param name="networkSpeedMbps">使用当前帧测得的网速，单位:Mbps </param>
        /// <returns> byte[] imageBytes, 返回的以byte数组形式存储的图片数据， 注意需要转换成float类型的数组后才可以进行访问 </returns>
        /// <returns> byte[] pointCloudBytes, 返回的以byte数组形式存储的点云数据， 注意需要转换成float类型的数组后才可以进行访问 </returns>

        public static (byte[] imageBytes, byte[] pointCloudBytes) GetPointCloudAndImageWithTimeStats(string ip, string frameId,
                                                         ref double networkTransmitTimeMs,
                                                         ref double networkSpeedMbps,
                                                         int timeout = 15000){
            if (string.IsNullOrEmpty(ip)) {
                return (null, null);
            }
            byte[] data = new byte[] { };
            double networkSpeedMbps_ = 0;
            double networkTransmitTimeMs_ = 0;
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            var request = new RestRequest(string.Format(_requestPaths["EpicRaw"], frameId), Method.GET);

            request.AdvancedResponseWriter = (stream, responseIn) => {
                var watch = new System.Diagnostics.Stopwatch();
                var memoryStream = new MemoryStream();
                var buffer = new byte[1024 * 128];
                long totalCount = 0;
                int bytesRead;
                watch.Start();
                while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) > 0) {
                    totalCount += bytesRead;
                    memoryStream.Write(buffer, 0, bytesRead);
                }
                watch.Stop();
                double elapsedSeconds = watch.ElapsedTicks / (System.Diagnostics.Stopwatch.Frequency * 1.0);
                networkTransmitTimeMs_ = elapsedSeconds * 1000L;
                networkSpeedMbps_ = responseIn.ContentLength / elapsedSeconds / 1024L / 1024L * 8;
                data = memoryStream.ToArray();
            };

            var response = restClient.Execute(request);
            networkTransmitTimeMs = networkTransmitTimeMs_;
            networkSpeedMbps = networkSpeedMbps_;
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return (null, null);
            }
            byte[] undistortLut = GetUndistortLut(ip);
            return (EpicRawDataService.DecodeImageFromEpicRaw(data), EpicRawDataService.DecodePointCloudFromEpicRaw(data, undistortLut));
        }
        public static (byte[] imageBytes, byte[] pointCloudBytes) DecodePointCloudAndImageFromEpicRaw(string ip, byte[] epicRow, int timeout = 15000) {
            byte[] undistortLut = GetUndistortLut(ip);
            return (EpicRawDataService.DecodeImageFromEpicRaw(epicRow), EpicRawDataService.DecodePointCloudFromEpicRaw(epicRow, undistortLut));
        }
        public static byte[] DecodePointCloudFromEpicRaw(byte[] epicRaw) {
            return EpicRawDataService.DecodePointCloudFromEpicRaw(epicRaw);
        }
        public static byte[] DecodeImageFromEpicRaw(byte[] epicRaw) {
            return EpicRawDataService.DecodeImageFromEpicRaw(epicRaw);
        }
        public static (int height, int width) GetShapeFromEpicRaw(byte[] epicRaw) {
            return EpicRawDataService.GetShapeFromEpicRaw(epicRaw);
        }

        /// <summary>
        /// 获取Ply字节数据
        /// </summary>
        public static byte[] GetPointCloudInPly(string ip, string frameId, int timeout=15000) {
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            var response = restClient.Get(
                new RestRequest(string.Format(_requestPaths["Ply"], frameId))
            );
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return null;
            }
            return response.RawBytes;
        }

        /// <summary> method 
        /// <c>SearchCamera</c> 自动搜索相机.
        /// </summary>
        /// <returns> List<EpicEyeInfo>, 以EpicEyeInfo形式返回的搜索到的相机列表，如果没有搜索到，则此列表为空</returns>
        public static List<EpicEyeInfo> SearchCamera() {
            IPEndPoint endPoint = new IPEndPoint(IPAddress.Parse("0.0.0.0"), 5668);
            UdpClient udpClient = new UdpClient(endPoint);
            udpClient.Client.ReceiveTimeout = 5000;

            List<EpicEyeInfo> epicEyeList = new List<EpicEyeInfo>();
            for (int i = 0; i < 6; i++) {
                byte[] data = udpClient.Receive(ref endPoint);
                if (data.Length == 0) {
                    continue;
                }
                EpicEyeInfo camera = Newtonsoft.Json.JsonConvert.DeserializeObject<EpicEyeInfo>(Encoding.UTF8.GetString(data));
                if (camera == null) {
                    continue;
                }
                if (string.IsNullOrEmpty(camera.IP)) {
                    camera.IP = endPoint.Address.ToString() + ":5000";
                }
                if (camera.IP.Contains("127.0.0.1")) {
                    camera.IP = camera.IP.Replace("127.0.0.1", endPoint.Address.ToString());
                }
                if (!camera.IP.Contains(":")) {
                    camera.IP += ":5000";
                }
                EpicEyeInfo cameraInList = epicEyeList.Where(x => x.IP == camera.IP).FirstOrDefault();
                if (cameraInList == null) {
                    if (string.IsNullOrEmpty(camera.IP)) {
                        continue;
                    }
                    epicEyeList.Add(camera);
                } else {
                    cameraInList = camera;
                }
            }
            udpClient.Close();
            return epicEyeList;
        }
    }
}