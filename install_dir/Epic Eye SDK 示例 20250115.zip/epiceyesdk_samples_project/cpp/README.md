# EpicEye SDK for cpp

本SDK没有外部依赖项，可直接编译运行

## build

```
mkdir build && cd build
cmake .. && make
```

## run

编译出来的库和samples二进制文件会存储在output文件夹中
```
output/
├── bin
│   ├── CameraConfig
│   ├── CameraInfo
│   ├── CameraParameters
│   ├── EpicEyeCapture
│   └── SearchCamera
└── lib
    └── libEpicEyeSDK.a
```