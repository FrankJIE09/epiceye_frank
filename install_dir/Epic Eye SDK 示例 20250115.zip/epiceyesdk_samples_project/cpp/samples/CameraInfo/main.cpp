#include "epiceye.h"

#include <iostream>
#include <iomanip>
#include <string>
#ifdef _WIN32
#include <Windows.h>
#endif

int main(int argc, char** argv) {
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
#endif
    std::cout << "---------------search EpicEye camera---------------" << std::endl;
    std::vector<TFTech::EpicEyeInfo> cameraList;
    if (TFTech::EpicEye::searchCamera(cameraList)) {
        std::cout << "Camera found: " << cameraList.size() << std::endl;
        for (int i = 0; i < cameraList.size(); i++) {
            std::cout << std::right << std::setw(3) << i << ": "
                      << std::left << std::setw(20) << std::setfill(' ') << cameraList[i].IP
                      << std::left << std::setw(30) << cameraList[i].SN << std::endl;
        }
    } else {
        std::cout << "Camera not found!" << std::endl;
    }

    std::cout << std::endl;

    for (int cameraIndex = 0; cameraIndex < cameraList.size(); cameraIndex++) {
        std::cout << std::endl;
        std::cout << "---------------get " << cameraList[cameraIndex].IP << " EpicEyeInfo-------------- - " << std::endl;
        TFTech::EpicEyeInfo info;
        if (!TFTech::EpicEye::getInfo(cameraList[cameraIndex].IP, info)) {
            std::cout << "getInfo failed!" << std::endl;
            continue;
        }
        std::cout << "SN: " << info.SN << std::endl;
        std::cout << "IP: " << info.IP << std::endl;
        std::cout << "model: " << info.model << std::endl;
        std::cout << "alias: " << info.alias << std::endl;
        std::cout << "resolution: " << info.width << "x" << info.height << std::endl;
    }

    std::cout << std::endl;
#ifdef _WIN32
    system("pause");
#endif
    return 0;
}