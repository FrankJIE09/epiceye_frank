#include "epiceye.h"
#include "nlohmann_json.hpp"

#include <iostream>
#include <iomanip>
#include <string>

void printConfigJson(nlohmann::json& configJson, std::string printOffset = "") {
    for (const auto& item : configJson.items()) {
        std::cout << printOffset << item.key() << ": ";
        if (!item.key().empty() && configJson[item.key()].is_object()) {
            std::cout << "{ " << std::endl;
            printConfigJson(configJson[item.key()], printOffset + "  ");
            std::cout << "}" << std::endl;
        }
        else if (!item.key().empty() && configJson[item.key()].is_array()) {
            std::cout << "[ " << std::endl;
            for (int i = 0; i < configJson[item.key()].size(); i++) {
                if (configJson[item.key()][i].is_object()) {
                    std::cout << "{ " << std::endl;
                    printConfigJson(configJson[item.key()][i], printOffset + "  ");
                    std::cout << "}" << std::endl;
                    continue;
                }
                std::cout << printOffset << item.value() << std::endl;
            }
            std::cout << "]" << std::endl;
        }
        else if (!item.key().empty()) {
            std::cout << item.value() << std::endl;
        }
    }
}

int main(int argc, char** argv) {
    std::cout << "---------------search EpicEye camera---------------" << std::endl;
    std::vector<TFTech::EpicEyeInfo> cameraList;
    if (TFTech::EpicEye::searchCamera(cameraList)) {
        std::cout << "Camera found: " << cameraList.size() << std::endl;
        for (int i = 0; i < cameraList.size(); i++) {
            std::cout << std::right << std::setw(3) << i << ": "
                << std::left << std::setw(20) << std::setfill(' ') << cameraList[i].IP
                << std::left << std::setw(30) << cameraList[i].SN << std::endl;
        }
    }
    else {
        std::cout << "Camera not found!" << std::endl;
    }

    std::cout << std::endl;

    for (int cameraIndex = 0; cameraIndex < cameraList.size(); cameraIndex++) {
        std::cout << "---------------get " << cameraList[cameraIndex].IP << " EpicEyeInfo-------------- - " << std::endl;
        nlohmann::json configJson;
        if (!TFTech::EpicEye::getConfig(cameraList[cameraIndex].IP, configJson)) {
            std::cout << "getConfig failed!" << std::endl;
            continue;
        }
        printConfigJson(configJson);
        if (!TFTech::EpicEye::setConfig(cameraList[cameraIndex].IP, configJson)) {
            std::cout << "setconfig failed!" << std::endl;
            continue;
        }
        std::cout << "setconfig successed!" << std::endl;
        std::cout << std::endl;
    }

    std::cout << std::endl;
#ifdef _WIN32
    system("pause");
#endif
    return 0;
}