#include "epiceye.h"

#include <iostream>
#include <iomanip>
#include <string>

int main(int argc, char** argv) {
    std::cout << "---------------search EpicEye camera---------------" << std::endl;
    std::vector<TFTech::EpicEyeInfo> cameraList;
    std::string ip;
    if (TFTech::EpicEye::searchCamera(cameraList)) {
        std::cout << "Camera found: " << cameraList.size() << std::endl;
        for (int i = 0; i < cameraList.size(); i++) {
            std::cout << std::right << std::setw(3) << i << ": "
                      << std::left << std::setw(20) << std::setfill(' ') << cameraList[i].IP
                      << std::left << std::setw(30) << cameraList[i].SN << std::endl;
        }
        ip = cameraList[0].IP;
    } else {
        std::cout << "Camera not found!" << std::endl;
    }
#ifdef _WIN32
    system("pause");
#endif
    return 0;
}