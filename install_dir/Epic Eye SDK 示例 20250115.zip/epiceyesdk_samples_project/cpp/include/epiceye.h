#ifndef TFTECH_EPICEYESDK_EPICEYE_H
#define TFTECH_EPICEYESDK_EPICEYE_H

#include "nlohmann_json.hpp"
#include <vector>

namespace TFTech {

struct EpicEyeInfo {
    std::string SN;         //序列号
    std::string IP;         //相机IP地址
    std::string model;      //相机的型号
    std::string alias;      //相机的别名,可通过Web UI进行更改
    uint32_t width = 0;     //图像的width
    uint32_t height = 0;    //图像的height
};

class EpicEye {
public:
    static std::string getSDKVersion();
    /**
     * @brief 获取相机信息
     * @return bool, 是否请求成功
     * @param ip,std::string 相机的ip地址
     * @param info, EpicEyeInfo 相机的详细信息,包含width，height
     */
    static bool getInfo(std::string ip, EpicEyeInfo &info);
    /**
    * @brief 触发拍摄一个Frame，一个Frame可能同时包含
    *        2D图像和点云数据，通过frameID进行索引，调用此方法后，会返回frameID，
    *        随后可以通过getImage和getPointCloud方法将数据取回
    * @return bool, 是否请求成功
    * @param ip,std::string 相机的ip地址
    * @param frameID, std::string 此次触发拍照返回的frameID
    * @param pointCloud, bool 表示是否请求点云数据，如果设为false，则此次触发的Frame仅包含2D图像数据
    */
    static bool triggerFrame(std::string ip, std::string &frameID, bool pointCloud = true);
    /**
     * @brief 根据frameID获取2D图像, 相关内存由SDK使用者进行申请和释放
     * @return bool, 是否请求成功
     * @param ip,std::string 相机的ip地址
     * @param frameID, std::string 待获取数据的frameID，可由triggerFrame获得
     * @param imageBuffer, void *  ,返回的图像数据，
     *        【注意】此imageBuffer的内存由SDK使用者进行申请和释放
     */
    static bool getImage(std::string ip, std::string frameID, void *imageBuffer, int &pixelByteSize);
    /**
     * @brief 根据frameID获取点云, 相关内存由SDK使用者进行申请和释放
     * @return bool, 是否请求成功
     * @param ip,std::string 相机的ip地址
     * @param frameID, std::string 待获取数据的frameID，可由triggerFrame获得
     * @param pointCloudBuffer, void *  ,返回的点云数据，
     *        【注意】此pointCloudBuffer的内存由SDK使用者进行申请和释放,大小为width*height*sizeof(float)*3
     */
    static bool getPointCloud(std::string ip, std::string frameID, float *pointCloudBuffer);
    /**
     * @brief 根据frameID获取深度圖, 相关内存由SDK使用者进行申请和释放
     * @return bool, 是否请求成功
     * @param ip,std::string 相机的ip地址
     * @param frameID, std::string 待获取数据的frameID，可由triggerFrame获得
     * @param depth, void *  ,返回的点云数据，
     *        注意】此depth的内存由SDK使用者进行申请和释放,大小为width*height*sizeof(float)
     */
    static bool getDepth(std::string ip, std::string frameID, float *depth);
    /**
     * @brief 根据frameID获取相机参数配置，如果frameID为空字符串""，则返回当前最新的相机配置参数
     * @return bool, 是否请求成功
     * @param ip,std::string 相机的ip地址
     * @param configJson, nlohmann::json 返回的相机配置数据
     * @param frameID, std::string 待获取数据的frameID，可由triggerFrame获得
     */
    static bool getConfig(std::string ip, nlohmann::json &configJson);
    /**
     * @brief 更新相机参数配置
     * @return bool, 是否请求成功
     * @param ip,std::string 相机的ip地址
     * @param configJson, nlohmann::json 待设置的相机配置数据
     */
    static bool setConfig(std::string ip, const nlohmann::json &configJson);
    /**
     * @brief 获取2D图像对应相机的相机矩阵
     * @return bool, 是否请求成功
     * @param ip,std::string 相机的ip地址
     * @param cameraMatrix, std::vector<float> 按行存储的相机矩阵，可恢复成3x3的camera matrix，
     *                                         与OpenCV兼容
     */
    static bool getCameraMatrix(std::string ip, std::vector<float> &cameraMatrix);
    /**
     * @brief 获取2D图像对应相机的畸变参数
     * @return bool, 是否请求成功
     * @param ip,std::string 相机的ip地址
     * @param distortion, std::vector<float> 相机的畸变参数，和OpenCV兼容
     */
    static bool getDistortion(std::string ip, std::vector<float> &distortion);
    /**
     * @brief 自动搜索相机
     * @return bool, 是否成功搜索到相机
     * @param cameraList, 以EpicEyeInfo形式返回的搜索到的相机列表，如果没有搜索到，则此列表为空
     */
    static bool searchCamera(std::vector<EpicEyeInfo> &cameraList);
};
}  // namespace TFTech

#endif
