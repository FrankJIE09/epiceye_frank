from .epiceye import *

SDK_VERSION = "3.3.0"


def get_sdk_version():
    return SDK_VERSION
