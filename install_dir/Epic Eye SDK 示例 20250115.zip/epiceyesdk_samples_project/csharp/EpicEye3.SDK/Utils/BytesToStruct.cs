using System.Runtime.InteropServices;

namespace TFTech.Utils {
    public class DataUtils {
        public static T? BytesToStruct<T>(byte[] bytes) {
            // 得到结构体的大小
            int size = GetSizeOfStruct<T>();
            // byte数组长度小于结构体的大小
            if (size > bytes.Length) {
                return default(T);
            }
            // 分配结构体大小的内存空间
            System.IntPtr structPtr = Marshal.AllocHGlobal(size);
            // 将byte数组拷到分配好的内存空间
            Marshal.Copy(bytes, 0, structPtr, size);
            // 将内存空间转换为目标结构体
            T? obj = Marshal.PtrToStructure<T>(structPtr);
            // 释放内存空间
            Marshal.FreeHGlobal(structPtr);
            // 返回结构体
            return obj;
        }

        public static int GetSizeOfStruct<T>() {
            return Marshal.SizeOf(typeof(T));
        }
    }
}