using System.Runtime.InteropServices;

namespace TFTech.Data {
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public class EpicRaw1 {
        public EpicRawHeader1? Header { get; set; } = new EpicRawHeader1();
        public byte[]? Data { get; set; }
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public class EpicRawHeader1 {                                                   // 168 bytes in total
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 8)]
        public string FileType = "EPICRAW1";                                        // 8  bytes
        public int Width { get; set; }                                              // 4  bytes
        public int Height { get; set; }                                             // 4  bytes
        public Matrix3x3 CameraMatrix { get; set; } = new Matrix3x3();              // 72 bytes
        public Distortion Distortion { get; set; } = new Distortion();              // 40 bytes
        public EpicEyeConfig EpicEye_Configure { get; set; } = new EpicEyeConfig(); // 28 bytes
        public int DataType { get; set; } = 4;                                      // 4  bytes
        public int DepthDataLength { get; set; } = 1;                               // 4  bytes
        public int ColorDataLength { get; set; } = 1;                               // 4  bytes
    }
}