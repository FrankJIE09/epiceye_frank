using System.Runtime.InteropServices;

namespace TFTech.Data {
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public class Distortion {
        public double K1 { get; set; }      // 8 bytes
        public double K2 { get; set; }      // 8 bytes
        public double P1 { get; set; }      // 8 bytes
        public double P2 { get; set; }      // 8 bytes
        public double K3 { get; set; }      // 8 bytes

        public double[] ToDoubleArray() {
            double[] ds = new double[5] {
                K1, K2, P1, P2, K3
            };
            return ds;
        }
    }
}