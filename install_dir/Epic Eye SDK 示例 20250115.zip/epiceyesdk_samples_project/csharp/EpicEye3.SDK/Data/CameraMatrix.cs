using System.Runtime.InteropServices;

namespace TFTech.Data {
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public class Matrix3x3 {
        public double M00 { get; set; }         // 8 bytes
        public double M01 { get; set; }         // 8 bytes
        public double M02 { get; set; }         // 8 bytes
        public double M10 { get; set; }         // 8 bytes
        public double M11 { get; set; }         // 8 bytes
        public double M12 { get; set; }         // 8 bytes
        public double M20 { get; set; }         // 8 bytes
        public double M21 { get; set; }         // 8 bytes
        public double M22 { get; set; }         // 8 bytes

        public double[] ToDoubleArray() {
            double[] ds = new double[9] {
                M00, M01, M02,
                M10, M11, M12,
                M20, M21, M22
            };
            return ds;
        }
    }
}