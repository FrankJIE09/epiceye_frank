using System.Runtime.InteropServices;

namespace TFTech.Data {

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public class EpicEyeConfig {

        /// <summary>
        /// 投影亮度 0/1/2
        /// </summary>
        public int ProjectorBrightness { get; set; } = 0;

        /// <summary>
        /// 2D 曝光时间（毫秒）
        /// </summary>
        public float Exptime2D { get; set; } = 40;

        /// <summary>
        /// 2D 曝光时间（毫秒）
        /// </summary>
        public float Exptime3D { get; set; } = 5;

        /// <summary>
        /// HDR 开关 
        /// </summary>
        public bool UseHDR { get; set; } = false;

        /// <summary>
        /// HDR 曝光时间（毫秒）
        /// </summary>
        public float ExpTimeHDR { get; set; } = 5;

        /// <summary>
        /// 使用PF滤波
        /// </summary>
        public bool UsePF { get; set; } = false;

        /// <summary>
        /// 使用SF滤波
        /// </summary>
        public bool UseSF { get; set; } = false;
    }
}
