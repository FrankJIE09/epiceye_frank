namespace TFTech.Data {
    public class EpicEyeInfo {
        public string Version { get; set; } = string.Empty;

        public string? SN { get; set; }

        public string? IP { get; set; }

        /// <summary>
        /// IPv6地址
        /// </summary>
        public string? IPv6 { get; set; }

        public string? Model { get; set; }

        public string? Alias { get; set; }

        public int Width { get; set; } = 2048;

        public int Height { get; set; } = 1536;

        public bool isDhcpEnabled = false;
    }
}
