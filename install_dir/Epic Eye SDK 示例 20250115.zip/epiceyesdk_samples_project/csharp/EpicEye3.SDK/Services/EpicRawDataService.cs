using TFTech.Data;
using DU = TFTech.Utils.DataUtils;
using System.Runtime.InteropServices;

namespace TFTech.Services {
    internal class EpicRawDataService {
        public const int EpicRaw1HeaderSize = 168;
        public const int EpicRaw2HeaderSize = 40;
        public static T? DecodeEpicRawHeader<T>(byte[] rawData) {
            int size = DU.GetSizeOfStruct<T>();
            return DU.BytesToStruct<T>(rawData.Take(size).ToArray());
        }

        public static (int height, int width) GetShapeFromEpicRaw(byte[] rawData) {
            string fileType = GetFileType(rawData);
            switch (fileType) {
                case "EPICRAW1":
                    EpicRawHeader1? header1 = DecodeEpicRawHeader<EpicRawHeader1>(rawData);
                    if (header1 is null) {
                        return (-1, -1);
                    }
                    return (header1.Height, header1.Width);
                case "EPICRAW2":
                    EpicRawHeader2? header2 = DecodeEpicRawHeader<EpicRawHeader2>(rawData);
                    if (header2 is null) {
                        return (-1, -1);
                    }
                    return (header2.Height, header2.Width);
                default:
                    if ((char)fileType[7] == 0) {
                        goto case "EPICRAW1";
                    }
                    Console.WriteLine("Unsupport type!");
                    return (-1, -1);
            }
        }

        public static byte[]? DecodeImageFromEpicRaw(byte[] rawData) {
            string fileType = GetFileType(rawData);
            switch (fileType) {
                case "EPICRAW1":
                    EpicRawHeader1? header1 = DecodeEpicRawHeader<EpicRawHeader1>(rawData);
                    if (header1 is null) {
                        return null;
                    }
                    return rawData.Skip(EpicRaw1HeaderSize + header1.DepthDataLength).Take(header1.ColorDataLength).ToArray();
                case "EPICRAW2":
                    EpicRawHeader2? header2 = DecodeEpicRawHeader<EpicRawHeader2>(rawData);
                    if (header2 is null) {
                        return null;
                    }
                    return rawData.Skip(
                        EpicRaw2HeaderSize +
                        header2.CameraMatrixLength +
                        header2.DistortionLength +
                        header2.ConfigStrLength +
                        header2.DepthDataLength
                    ).Take(header2.ImageDataLength).ToArray();
                default:
                    if ((char)fileType[7] == 0) {
                        goto case "EPICRAW1";
                    }
                    Console.WriteLine("Unsupport type!");
                    return null;
            }
        }

        public static byte[]? DecodePointCloudFromEpicRaw(byte[]? rawData, byte[]? undistortLut = null) {
            if(rawData == null){
                return null;
            }
            string fileType = GetFileType(rawData);
            byte[]? depthData = GetDepthFromEpicRaw(rawData, fileType);
            if (depthData is null) {
                return null;
            }
            switch (fileType) {
                case "EPICRAW1":
                    EpicRawHeader1? header1 = DecodeEpicRawHeader<EpicRawHeader1>(rawData);
                    if (header1 is null) {
                        return null;
                    }
                    return DecodePointCloudFromDepth(depthData, header1.CameraMatrix, header1.Width, header1.Height, undistortLut);

                case "EPICRAW2":
                    EpicRawHeader2? header2 = DecodeEpicRawHeader<EpicRawHeader2>(rawData);
                    if (header2 is null) {
                        return null;
                    }
                    Matrix3x3? cameraMatrix = DU.BytesToStruct<Matrix3x3>(
                        rawData.Skip(EpicRaw2HeaderSize).Take(header2.CameraMatrixLength).ToArray()
                    );
                    if (cameraMatrix is null) {
                        return null;
                    }
                    return DecodePointCloudFromDepth(depthData, cameraMatrix, header2.Width, header2.Height, undistortLut);
                default:
                    if ((char)fileType[7] == 0) {
                        goto case "EPICRAW1";
                    }
                    Console.WriteLine("Unsupport type!");
                    return null;
            }
        }

        public static byte[]? GetDepthFromEpicRaw(byte[] rawData, string? fileType = null) {
            if (string.IsNullOrEmpty(fileType)) {
                fileType = GetFileType(rawData);
            }
            switch (fileType) {
                case "EPICRAW1":
                    EpicRawHeader1? header1 = DecodeEpicRawHeader<EpicRawHeader1>(rawData);
                    if (header1 is null) {
                        return null;
                    }
                    return rawData.Skip(EpicRaw1HeaderSize).Take(header1.DepthDataLength).ToArray();
                case "EPICRAW2":
                    EpicRawHeader2? header2 = DecodeEpicRawHeader<EpicRawHeader2>(rawData);
                    if (header2 is null) {
                        return null;
                    }
                    return rawData.Skip(
                        EpicRaw2HeaderSize +
                        header2.CameraMatrixLength +
                        header2.DistortionLength +
                        header2.ConfigStrLength
                    ).Take(header2.DepthDataLength).ToArray();
                default:
                    if ((char)fileType[7] == 0) {
                        goto case "EPICRAW1";
                    }
                    Console.WriteLine("Unsupport type!");
                    return null;
            }
        }

        public static byte[] DecodePointCloudFromDepth(byte[] depthData, Matrix3x3 cameraMatrix, int width, int height, byte[]? undistortLut = null) {
            byte[] pointCloudBytes = new byte[width * height * 3 * 4];

            Parallel.For(0, height, i => {
                Span<float> pointCloudFloatsSpan = MemoryMarshal.Cast<byte, float>(pointCloudBytes);
                ReadOnlySpan<float> depthFloatsSpan = MemoryMarshal.Cast<byte, float>(depthData);
                ReadOnlySpan<float> lutFloatsSpan = MemoryMarshal.Cast<byte, float>(undistortLut);

                for (int j = 0; j < width; j++) {
                    int p = Convert.ToInt32(width * i + j);
                    int pPointCloud = p * 3;
                    float Z = depthFloatsSpan[p];

                    if (Z < 0.1 || Z > 6000.0) {
                        pointCloudFloatsSpan[pPointCloud + 2] = float.NaN;
                        continue;
                    }

                    float u = j;
                    float v = i;
                    if (undistortLut is not null && undistortLut.Length > 0) {
                        int pLut = p * 2;
                        u = lutFloatsSpan[pLut];
                        v = lutFloatsSpan[pLut + 1];
                    }
                    pointCloudFloatsSpan[pPointCloud] = (float)(Z * (u - cameraMatrix.M02) / cameraMatrix.M00);
                    pointCloudFloatsSpan[pPointCloud + 1] = (float)(Z * (v - cameraMatrix.M12) / cameraMatrix.M11);
                    pointCloudFloatsSpan[pPointCloud + 2] = Z;
                }
            });
            return pointCloudBytes;
        }

        private static string GetFileType(byte[] rawData) {
            return System.Text.Encoding.ASCII.GetString(rawData, 0, 8);
        }
    }
}