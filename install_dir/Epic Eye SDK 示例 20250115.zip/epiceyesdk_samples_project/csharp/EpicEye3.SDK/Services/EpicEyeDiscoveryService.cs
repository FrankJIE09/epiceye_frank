using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using Newtonsoft.Json;
using TFTech.Data;

namespace TFTech.Services {
    public class EpicEyeDiscoveryService {
        private static bool _started = false;
       
        private static IPAddress _ipv6MulticastAddress = IPAddress.Parse("ff02::fb");
        private static IPAddress _ipv4MulticastAddress = IPAddress.Parse("224.0.0.251");
        private static List<int> _portCandidates = new List<int> { 5665, 5666, 5667, 5668 };
        private static Socket _socketIpv6 = new Socket(AddressFamily.InterNetworkV6, SocketType.Dgram, ProtocolType.Udp);
        private static Socket _socketIpv4 = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        private static List<EpicEyeInfo> _epiceyeList = new List<EpicEyeInfo>();
        private static readonly object _epiceyeListLock = new object();
        private static CancellationTokenSource _cancellationTokenSource = new CancellationTokenSource();


        private static void JoinMulticastGroupAllInterface(Socket socket, IPAddress multicastAddress) {
            foreach (NetworkInterface networkInterface in NetworkInterface.GetAllNetworkInterfaces()) {
                IPInterfaceProperties ipProperties = networkInterface.GetIPProperties();
                    
                if (!networkInterface.SupportsMulticast) {
                    Console.WriteLine($"Multicast do not supported on {networkInterface.Name}.");
                    continue; // multicast is meaningless for this type of connection
                }
                    
                if (OperationalStatus.Up != networkInterface.OperationalStatus) {
                    Console.WriteLine($"{networkInterface.Name} not up.");
                    continue; // this adapter is off or not connected
                }
               
                int ifIndex = -1;
                if (socket.AddressFamily == AddressFamily.InterNetwork) {
                    IPv4InterfaceProperties p = ipProperties.GetIPv4Properties();
                    if (null == p) {
                        continue; // IPv4 is not configured on this adapter
                    }
                    ifIndex = p.Index;
                    socket.SetSocketOption(SocketOptionLevel.IP, SocketOptionName.AddMembership, new MulticastOption(multicastAddress, ifIndex));
                    Console.WriteLine($"Joined ipv4 multicast group on interface {networkInterface.Name} with ifindex {ifIndex}");
                }
                if (socket.AddressFamily == AddressFamily.InterNetworkV6) {
                    IPv6InterfaceProperties p = ipProperties.GetIPv6Properties();
                    if (null == p) {
                        continue; // IPv4 is not configured on this adapter
                    }
                    ifIndex = p.Index;
                    socket.SetSocketOption(SocketOptionLevel.IPv6, SocketOptionName.AddMembership, new IPv6MulticastOption(multicastAddress, ifIndex));
                    Console.WriteLine($"Joined ipv6 multicast group on interface {networkInterface.Name} with ifindex {ifIndex}");
                }
                if (ifIndex < 0) {
                    continue;
                }
                
            }
        }

        public static void Start() {
            if (!_started) {
                _started = true;
                _cancellationTokenSource = new CancellationTokenSource();
                
                // bind ipv6 port 
                foreach (int port in _portCandidates) {
                    try {
                        _socketIpv6 = new Socket(AddressFamily.InterNetworkV6, SocketType.Dgram, ProtocolType.Udp);
                        _socketIpv6.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);

                        IPEndPoint endPointIpv6 = new IPEndPoint(IPAddress.IPv6Any, port);
                        _socketIpv6.Bind(endPointIpv6);
                        JoinMulticastGroupAllInterface(_socketIpv6, _ipv6MulticastAddress);
                        Task.Run(() => ListenForBroadcastsAsync(_socketIpv6, "IPv6", _cancellationTokenSource.Token));
                        Console.WriteLine($"Bind to local endpoint: {_socketIpv6.LocalEndPoint}");
                        break;
                    } catch (SocketException e) {
                        Console.WriteLine($"faild to bind to ipv6 port: {port}, exception: {e.ToString()}");
                    }
                }

                // bind ipv4 port 
                foreach (int port in _portCandidates) {
                    try {
                        _socketIpv4 = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
                        _socketIpv4.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
                        IPEndPoint endPointIpv4 = new IPEndPoint(IPAddress.Any, port);
                        _socketIpv4.Bind(endPointIpv4);
                        JoinMulticastGroupAllInterface(_socketIpv4, _ipv4MulticastAddress);
                        Task.Run(() => ListenForBroadcastsAsync(_socketIpv4, "IPv4", _cancellationTokenSource.Token));
                        Console.WriteLine($"Bind to local endpoint: {_socketIpv4.LocalEndPoint}");
                        break;
                    } catch (SocketException e) {
                        Console.WriteLine($"faild to bind to ipv4 port: {port}, exception: {e.ToString()}");
                    }
                }
            }
        }

        /// <summary>
        /// 停止
        /// </summary>
        public static void Stop() {
            _cancellationTokenSource.Cancel();
            _socketIpv6.Close();
            _socketIpv6.Dispose();
            _socketIpv4.Close();
            _socketIpv4.Dispose();
            _started = false;
        }

        /// <summary>
        /// 释放
        /// </summary>
        public static void Dispose() {
            Stop();
        }

        /// <summary>
        /// 获取发现相机列表
        /// </summary>
        /// <returns></returns>
        public static List<EpicEyeInfo> GetEpicEyeList() {
            return _epiceyeList;
        }

        /// <summary>
        /// 清除发现相机列表
        /// </summary>
        /// <returns></returns>
        public static List<EpicEyeInfo> ClearEpicEyeList() {
            _epiceyeList.Clear();
            return _epiceyeList;
        }

        public delegate void EpicEyeListUpdatedHandler();
        public static event EpicEyeListUpdatedHandler EpicEyeListUpdatedEvent;
        private static async Task ListenForBroadcastsAsync(Socket socket, string protocol, CancellationToken token) {
            try {
                while (!token.IsCancellationRequested) {
                    await Task.Delay(100, token);
                    byte[] buffer = new byte[1024];

                    var (receivedBytes, remoteEndpoint) = await ReceiveFromAsync(socket, buffer, 0, buffer.Length, SocketFlags.None);
                    if (receivedBytes <= 0)
                        continue;

                    string receivedData = Encoding.UTF8.GetString(buffer, 0, receivedBytes);
                    // Console.WriteLine($"Received: {receivedData} on {protocol} from {remoteEndpoint}");
                    EpicEyeInfo? epicEyeInfo = null;
                    try {
                        epicEyeInfo = JsonConvert.DeserializeObject<EpicEyeInfo>(receivedData);
                    } catch (JsonException ex) {
                        Console.WriteLine($"Received: {receivedData} on {protocol} from {remoteEndpoint}");
                        Console.WriteLine($"Failed to deserialize data on {protocol} from {remoteEndpoint}: {ex.Message}");
                        continue; // 跳过无效的数据包
                    }
                    lock (_epiceyeListLock) {
                        if (null != epicEyeInfo) {
                            EpicEyeInfo? firstEpicEyeInfo = _epiceyeList.
                            Where(x => x.SN == epicEyeInfo.SN && x.IP == epicEyeInfo.IP && x.IPv6 == epicEyeInfo.IPv6)
                            .FirstOrDefault();
                            if (firstEpicEyeInfo == null) {
                                _epiceyeList.Add(epicEyeInfo);
                                if (EpicEyeListUpdatedEvent != null) EpicEyeListUpdatedEvent();
                            } 
                        }
                    }
                }
            } catch (Exception ex) {
                Console.WriteLine($"An error occurred while listening on {protocol}: {ex.Message}");
            }
        }

        private static Task<(int bytesReceived, EndPoint remoteEP)> ReceiveFromAsync(Socket socket, byte[] buffer, int offset, int size, SocketFlags socketFlags) {
            var tcs = new TaskCompletionSource<(int, EndPoint)>();
            EndPoint remoteEP = new IPEndPoint(socket.AddressFamily == AddressFamily.InterNetworkV6 ? IPAddress.IPv6Any : IPAddress.Any, 0);
            socket.BeginReceiveFrom(buffer, offset, size, socketFlags, ref remoteEP, ar => {
                try {
                    int bytesReceived = socket.EndReceiveFrom(ar, ref remoteEP);
                    tcs.SetResult((bytesReceived, remoteEP));
                } catch (Exception ex) {
                    tcs.SetException(ex);
                }
            }, null);

            return tcs.Task;
        }
    }
}
