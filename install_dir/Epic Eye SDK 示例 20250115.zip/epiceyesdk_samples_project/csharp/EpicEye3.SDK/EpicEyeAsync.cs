using System.Collections;
using RestSharp;
using TFTech.Data;
using TFTech.Services;

namespace TFTech {
    public partial class EpicEye {
        /// <summary>method
        /// <c>GetHeader</c> 获取相机照片信息.
        /// </summary>
        /// <param ip="ip"> 相机的IP地址 </param>
        /// <param name="frameId"> 相机的frameId </param>
        /// <returns> EpicRawHeader, 相机的照片信息,包含width，height </returns>
        public static async ValueTask<string?> GetHeaderAsync(string ip, string frameId, int timeout=2000) {
            if (string.IsNullOrEmpty(ip)) {
                return null;
            }
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            RestRequest request = new RestRequest(string.Format(_requestPaths["GetHeader"]) + frameId, Method.GET);
            IRestResponse response = await restClient.ExecuteAsync(request);
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return null;
            }
            return response.Content;
        }

        /// <summary>method 
        /// <c>GetInfo</c> 获取相机信息.
        /// </summary>
        /// <param name="ip"> 相机的ip地址 </param> 
        /// <returns> EpicEyeInfo, 相机的详细信息,包含width，height </returns>
        public static async ValueTask<EpicEyeInfo?> GetInfoAsync(string ip, int timeout=2000) {
            if (string.IsNullOrEmpty(ip)) {
                return null;
            }
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            RestRequest request = new RestRequest(_requestPaths["GetInfo"]);
            IRestResponse response = await restClient.ExecuteAsync(request);
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return null;
            }
            return Newtonsoft.Json.JsonConvert.DeserializeObject<EpicEyeInfo>(response.Content);
        }

        /// <summary>method  
        /// <c>TriggerFrame</c> 触发拍摄一个Frame，一个Frame可能同时包含
        ///                     2D图像和点云数据，通过frameID进行索引，调用此方法后，会返回frameID，
        ///                     随后可以通过getImage和getPointCloud方法将数据取回
        /// </summary>
        /// <param name="ip"> 相机的ip地址 </param>
        /// <param name="pointcloud"> 表示是否请求点云数据，如果设为false，则此次触发的Frame仅包含2D图像数 </param> 
        /// <returns> EpicEyeInfo, 相机的详细信息,包含width，height </returns>
        public static async ValueTask<string?> TriggerCaptureAsync(string? ip, bool pointcloud = true, int timeout=2000) {
            if (string.IsNullOrEmpty(ip)) {
                return null;
            }
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            RestRequest request = new RestRequest(string.Format(_requestPaths["TriggerCapture"], pointcloud));
            request.Method = Method.POST;
            IRestResponse response = await restClient.ExecuteAsync(request);
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return null;
            }
            return Newtonsoft.Json.JsonConvert.DeserializeObject<string>(response.Content);
        }

        /// <summary>method 
        /// <c>GetPointCloud</c> 根据frameID获取点云.
        /// </summary>
        /// <param name="ip"> 相机的ip地址 </param> 
        /// <param name="frameId"> 待获取数据的frameID，可由triggerFrame获得 </param>
        /// <returns> byte[], 返回的以byte数组形式存储的点云数据， 注意需要转换成float类型的数组后才可以进行访问 </returns>
        public static async ValueTask<byte[]?> GetPointCloudAsync(string ip, string frameId, int timeout=15000) {
            if (string.IsNullOrEmpty(ip)) {
                return null;
            }
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            RestRequest request = new RestRequest(string.Format(_requestPaths["Depth"], frameId));
            IRestResponse response = await restClient.ExecuteAsync(request);
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return null;
            }
            byte[] data = response.RawBytes;
            byte[]? undistortLut = GetUndistortLut(ip);
            return EpicRawDataService.DecodePointCloudFromEpicRaw(data, undistortLut);
        }

        /// <summary>method 
        /// <c>GetDepth</c> 根据frameID获取深度图.
        /// </summary>
        /// <param name="ip">相机的ip地址 </param>
        /// <param name="frameId">待获取数据的frameID，可由triggerFrame获得</param>
        /// <returns>byte[], 返回的以byte数组形式存储的深度数据， 注意需要转换成float类型的数组后才可以进行访问</returns>
        public static async ValueTask<byte[]?> GetDepthAsync(string ip, string frameId, int timeout=15000) {
            if (string.IsNullOrEmpty(ip)) {
                return null;
            }
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            RestRequest request = new RestRequest(string.Format(_requestPaths["Depth"], frameId));
            IRestResponse response = await restClient.ExecuteAsync(request);
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return null;
            }
            byte[] data = response.RawBytes;
            return EpicRawDataService.GetDepthFromEpicRaw(data);
        }

        public static async ValueTask<byte[]?> GetImageAsync(string ip, string frameId, int timeout=15000) {
            if (string.IsNullOrEmpty(ip)) {
                return null;
            }
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            RestRequest request = new RestRequest(string.Format(_requestPaths["EpicRaw"], frameId));
            IRestResponse response = await restClient.ExecuteAsync(request);
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return null;
            }
            byte[] data = response.RawBytes;
            return EpicRawDataService.DecodeImageFromEpicRaw(data);
        }

        /// <summary>method 
        /// <c>GetConfig</c> 根据frameID获取相机参数配置，如果frameID为空字符串""，则返回当前最新的相机配置参数.
        /// </summary>
        /// <param name="ip">相机的ip地址 </param> 
        /// <param name="frameId">待获取数据的frameID，可由triggerFrame获得</param>
        /// <returns>EpicEyeConfig, 返回的相机配置数据</returns>
        public static async ValueTask<Hashtable?> GetConfigAsync(string ip, string frameId = "", int timeout=2000) {
            if (string.IsNullOrEmpty(ip)) {
                return null;
            }
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            RestRequest request = new RestRequest(string.Format(_requestPaths["GetConfig"], frameId));
            IRestResponse response = await restClient.ExecuteAsync(request);
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return null;
            }
            var configObject = Newtonsoft.Json.JsonConvert.DeserializeObject(response.Content.ToString());
            return Newtonsoft.Json.JsonConvert.DeserializeObject<Hashtable>(configObject?.ToString());
        }

        /// <summary>method 
        /// <c>SetConfig</c> 更新相机参数配置.
        /// </summary>
        /// <param name="ip">相机的ip地址 </param> 
        /// <param name="config">待设置的相机配置数据</param>
        /// <returns>bool,是否请求成功</returns>
        public static async ValueTask<bool> SetConfigAsync(string ip, Hashtable config, int timeout=2000) {
            if (string.IsNullOrEmpty(ip)) {
                return false;
            }
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            RestRequest request = new RestRequest(_requestPaths["SetConfig"]);
            request.AddJsonBody(Newtonsoft.Json.JsonConvert.SerializeObject(config));
            IRestResponse response = await restClient.ExecuteAsync(request);
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return false;
            }
            return true;
        }

        /// <summary>method 
        /// <c>GetCameraMatrix</c> 获取2D图像对应相机的相机矩阵.
        /// </summary>
        /// <param name="ip">相机的ip地址 </param> 
        /// <returns>float[],按行存储的相机矩阵，可恢复成3x3的camera matrix，与OpenCV兼容</returns>
        public static async ValueTask<float[]?> GetCameraMatrixAsync(string ip, int timeout=2000) {
            if (string.IsNullOrEmpty(ip)) {
                return null;
            }
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            RestRequest request = new RestRequest(_requestPaths["CameraMatrix"]);
            IRestResponse response = await restClient.ExecuteAsync(request);
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return null;
            }
            return Newtonsoft.Json.JsonConvert.DeserializeObject<float[]>(response.Content);
        }

        /// <summary>method 
        /// <c>GetDistortion</c> 获取2D图像对应相机的畸变参数.
        /// </summary>
        /// <param name="ip">相机的ip地址 </param>
        /// <returns>float[], 相机的畸变参数，和OpenCV兼容</returns>
        public static async ValueTask<float[]?> GetDistortionAsync(string ip, int timeout=2000) {
            if (string.IsNullOrEmpty(ip)) {
                return null;
            }
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            RestRequest request = new RestRequest(_requestPaths["Distortion"]);
            IRestResponse response = await restClient.ExecuteAsync(request);
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return null;
            }
            return Newtonsoft.Json.JsonConvert.DeserializeObject<float[]>(response.Content);
        }

        /// <summary>
        /// 获取EpicRaw字节数据
        /// </summary>
        public static async ValueTask<byte[]?> GetFrameInEpicRawAsync(string ip, string frameId, int timeout=15000) {
            double networkSpeedMbps_ = 0;
            double networkTransmitTimeMs_ = 0;
            byte[]? data = new byte[] { };
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            var request = new RestRequest(string.Format(_requestPaths["EpicRaw"], frameId), Method.GET);
            request.AdvancedResponseWriter = (stream, response) => {
                var watch = new System.Diagnostics.Stopwatch();
                using var memoryStream = new MemoryStream();
                var buffer = new byte[1024 * 128];
                long totalCount = 0;
                int bytesRead;
                watch.Start();
                while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) > 0)
                {
                    totalCount += bytesRead;
                    memoryStream.Write(buffer, 0, bytesRead);
                }
                watch.Stop();
                double elapsedSeconds = watch.ElapsedTicks / (System.Diagnostics.Stopwatch.Frequency * 1.0);
                networkTransmitTimeMs_ = elapsedSeconds * 1000L;
                networkSpeedMbps_ = response.ContentLength / elapsedSeconds / 1024L / 1024L * 8;
                data = memoryStream.ToArray();
            };
            var response = await restClient.ExecuteAsync(request);
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return null;
            }
            return data;
        }

        /// <summary>
        /// 获取EpicRaw字节数据
        /// </summary>
        public static async ValueTask<(byte[]? imageBytes, byte[]? pointCloudBytes)> GetFrameInEpicRawDecodeUndistortLutAsync(string ip, string frameId, int timeout = 15000) {
            double networkSpeedMbps_ = 0;
            double networkTransmitTimeMs_ = 0;
            byte[]? data = new byte[] { };
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            var request = new RestRequest(string.Format(_requestPaths["EpicRaw"], frameId), Method.GET);

            request.AdvancedResponseWriter = (stream, response) => {
                var watch = new System.Diagnostics.Stopwatch();
                using var memoryStream = new MemoryStream();
                var buffer = new byte[1024 * 128];
                long totalCount = 0;
                int bytesRead;

                watch.Start();
                while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) > 0) {
                    totalCount += bytesRead;
                    memoryStream.Write(buffer, 0, bytesRead);
                }
                watch.Stop();
                double elapsedSeconds = watch.ElapsedTicks / (System.Diagnostics.Stopwatch.Frequency * 1.0);
                networkTransmitTimeMs_ = elapsedSeconds * 1000L;
                networkSpeedMbps_ = response.ContentLength / elapsedSeconds / 1024L / 1024L * 8;
                data = memoryStream.ToArray();
            };

            var response = await restClient.ExecuteAsync(request);
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return (null, null);
            }
            if (data == null) {
                return (null, null);
            }
            byte[]? undistortLut = GetUndistortLut(ip);
            return (EpicRawDataService.DecodeImageFromEpicRaw(data), EpicRawDataService.DecodePointCloudFromEpicRaw(data, undistortLut));
        }

        /// <summary>
        /// 获取Ply字节数据
        /// </summary>
        public static async ValueTask<byte[]?> GetPointCloudInPlyAsync(string ip, string frameId, int timeout=15000) {
            RestClient restClient = new RestClient(string.Format(_baseUrl, ip));
            restClient.Timeout = timeout;
            RestRequest request = new RestRequest(string.Format(_requestPaths["Ply"], frameId));
            IRestResponse response = await restClient.ExecuteAsync(request);
            if (response.StatusCode != System.Net.HttpStatusCode.OK) {
                return null;
            }
            return response.RawBytes;
        }
    }
}
