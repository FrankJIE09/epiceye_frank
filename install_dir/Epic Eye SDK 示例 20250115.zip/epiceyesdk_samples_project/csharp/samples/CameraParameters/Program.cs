﻿using TFTech;
using TFTech.Data;
using TFTech.Services;

namespace EpicEye3.SDK.Example {
    public class Program {
        public static void Main(string[] args) {
            Console.WriteLine("----------------Searching Camera----------------");
            List<EpicEyeInfo> epicEyeList = EpicEye.SearchCamera();
            foreach (EpicEyeInfo item in epicEyeList) {
                Console.WriteLine("SN: " + item.SN + "  IP: " + item.IP + "  别名: " + item.Alias);
            }

            Console.WriteLine("-----------------Get Camera Parameters----------------");
            foreach (EpicEyeInfo item in epicEyeList) {
                float[] cameraMatrix = EpicEye.GetCameraMatrix(item.IP);
                if(cameraMatrix is null) {
                    Console.WriteLine("GetCameraMatrix failed!");
                } else {
                    Console.WriteLine("cameraMatrix: " + string.Join(", ", cameraMatrix));
                }

                float[] distortion = EpicEye.GetDistortion(item.IP);
                if (distortion is null) {
                    Console.WriteLine("GetDistortion failed!");
                } else {
                    Console.WriteLine("distortion: " + string.Join(", ", distortion));
                }
            }
        }
    }
}