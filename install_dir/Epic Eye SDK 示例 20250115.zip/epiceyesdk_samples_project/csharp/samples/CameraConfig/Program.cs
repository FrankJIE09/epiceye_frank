﻿using System.Collections;
using TFTech;
using TFTech.Data;
using TFTech.Services;

namespace EpicEye3.SDK.Example {
    public class Program {
        public static void Main(string[] args) {
            Console.WriteLine("----------------Searching Camera----------------");
            List<EpicEyeInfo> epicEyeList = EpicEye.SearchCamera();
            foreach (EpicEyeInfo item in epicEyeList) {
                Console.WriteLine("SN: " + item.SN + "  IP: " + item.IP + "  别名: " + item.Alias);
            }

            Console.WriteLine("-----------------Get CameraConfig----------------");
            foreach (EpicEyeInfo item in epicEyeList) {
                Hashtable configFromCamera = EpicEye.GetConfig(item.IP);
                Console.WriteLine($"CameraIP: {item.IP}");
                if(configFromCamera is null){
                    Console.WriteLine("GetConfig failed!");
                } else {
                    foreach(object key in configFromCamera.Keys) {
                        Console.WriteLine($"{key}: {configFromCamera[key]}");
                    }
                }

                if(EpicEye.SetConfig(item.IP, configFromCamera)) {
                    Console.WriteLine("SetConfig successfully!");
                    foreach(object key in configFromCamera.Keys) {
                        Console.WriteLine($"{key}: {configFromCamera[key]}");
                    }
                } else {
                    Console.WriteLine("SetConfig failed!");
                }

                Console.WriteLine("\n");
            }
        }
    }
}