﻿using TFTech;
using TFTech.Data;
using TFTech.Services;

namespace EpicEye3.SDK.Example {
    public class Program {
        public static void Main(string[] args) {
            Console.WriteLine("----------------Searching Camera----------------");
            List<EpicEyeInfo> epicEyeList = EpicEye.SearchCamera();
            foreach (EpicEyeInfo item in epicEyeList) {
                Console.WriteLine("SN: " + item.SN + "  IP: " + item.IP + "  别名: " + item.Alias);
            }
        }
    }
}