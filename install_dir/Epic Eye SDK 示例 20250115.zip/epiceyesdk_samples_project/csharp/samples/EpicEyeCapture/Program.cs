﻿using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.PixelFormats;
using TFTech;
using TFTech.Data;
using TFTech.Services;

namespace EpicEye3.SDK.Example {
    public class Program {
        public static void Main(string[] args) {
            string ip;
            if(args.Length > 0) {
                ip = args[0];
                Console.WriteLine("Using IP: " + ip);
            } else {
                Console.WriteLine("-----------------Searching Camera----------------");
                List<EpicEyeInfo> epicEyeList = EpicEye.SearchCamera();
                foreach (EpicEyeInfo item in epicEyeList) {
                    Console.WriteLine("SN: " + item.SN + "  IP: " + item.IP + "  别名: " + item.Alias + "  请使用浏览器打开 http://" + item.IP + "");
                }
                ip = epicEyeList[0].IP;
            }

            Console.WriteLine("-----------------GetInfo----------------");
            EpicEyeInfo info = EpicEye.GetInfo(ip);
            foreach (PropertyDescriptor descriptor in TypeDescriptor.GetProperties(info)) {
                Console.WriteLine("{0}: {1}", descriptor.Name, descriptor.GetValue(info));
            }

            Console.WriteLine("-----------------TriggerCapture----------------");
            string frameId = EpicEye.TriggerCapture(ip, true);
            if (frameId is null) {
                Console.WriteLine("TriggerFrame failed!");
                return;
            } else {
                Console.WriteLine("frameId: " + frameId);
            }

            Console.WriteLine("-----------------get image ----------------");
            byte[] imageBytes = EpicEye.GetImage(ip, frameId);
            if(imageBytes is null) {
                Console.WriteLine("GetImage failed!");
            } else {
                int bytesPerPixel = imageBytes.Length / info.Width / info.Height;
                switch (bytesPerPixel) {
                    case 3:
                        Image<Bgr24> image24 = Image.LoadPixelData<Bgr24>(imageBytes, info.Width, info.Height);
                        image24.Save("image.png");
                        Console.WriteLine("Image saved to image.png!");
                        break;
                    case 6:
                        Image<Rgb48> image48 = Image.LoadPixelData<Rgb48>(imageBytes, info.Width, info.Height);
                        ImageConvertor.ConvertRgb48ToBgr24(image48).Save("image.png");
                        Console.WriteLine("Image saved to image.png!");
                        break;
                    default:
                        Console.WriteLine("Length of Bytes is incorrect.");
                        break;
                }
            }

            Console.WriteLine("-----------------get depth ----------------");
            byte[] depthBytes = EpicEye.GetDepth(ip, frameId);
            if(depthBytes is null) {
                Console.WriteLine("GetDepth failed!");
            } else {
                Image<L8> image8 = ImageConvertor.ConvertDepthToGray(info.Height, info.Width, depthBytes);
                image8.Save("depth.png");
                Console.WriteLine("Depth saved to depth.png");
            }

            Console.WriteLine("-----------------get GetPointCloud ----------------");
            byte[] pointCloudBytes = EpicEye.GetPointCloud(ip, frameId);
            if(pointCloudBytes is null) {
                Console.WriteLine("GetPointCloud failed!");
            } else {
                PlyWriter.Save("cloud.ply", pointCloudBytes);
                Console.WriteLine("Pointcloud saved to cloud.ply!");
            }
        }
    }

    class ImageConvertor {
        public static Image<Bgr24> ConvertRgb48ToBgr24(Image<Rgb48> image) {
            Image<Bgr24> targetImage = new(image.Width, image.Height);
            image.ProcessPixelRows(targetImage, (sourceAccessor, targetAccessor) => {
                for (int y = 0; y < sourceAccessor.Height; y++) {
                    Span<Rgb48> sourcePixelRow = sourceAccessor.GetRowSpan(y);
                    Span<Bgr24> targetPixelRow = targetAccessor.GetRowSpan(y);
                    for (int x = 0; x < sourcePixelRow.Length; x++) {
                        ref Rgb48 pixelS = ref sourcePixelRow[x];
                        ref Bgr24 pixelT = ref targetPixelRow[x];
                        pixelT.R = (byte)(pixelS.B >> 2);
                        pixelT.G = (byte)(pixelS.G >> 2);
                        pixelT.B = (byte)(pixelS.R >> 2);
                    }
                }
            });
            return targetImage;
        }

        public static Image<L8> ConvertDepthToGray(int height, int width, byte[] depthBytes) {
            Image<L8> targetImage = new(width, height);
            float[] depthFloats = new float[height * width];
            Buffer.BlockCopy(depthBytes, 0, depthFloats, 0, depthBytes.Length);
            float maxDepth = depthFloats.Max();
            float minDepth = depthFloats.Min();
            float depthRange = maxDepth - minDepth;
            targetImage.ProcessPixelRows((sourceAccessor) => {
                for (int y = 0; y < sourceAccessor.Height; y++) {
                    Span<L8> sourcePixelRow = sourceAccessor.GetRowSpan(y);
                    for (int x = 0; x < sourcePixelRow.Length; x++) {
                        ref L8 pixelT = ref sourcePixelRow[x];
                        pixelT.PackedValue = (byte)Math.Round((depthFloats[y * width + x] - minDepth) / depthRange * 255);
                    }
                }
            });
            return targetImage;
        }
    }

    class PlyWriter{
        public static void Save(string filename, byte[] pointCloudBytes) {
            int pointCount = pointCloudBytes.Length / 3 / sizeof(float);
            BinaryWriter writer = new BinaryWriter(new FileStream(filename, FileMode.Create), Encoding.ASCII);
            //Write the headers for 3 vertices
            writer.Write(str2byteArray("ply\n"));
            writer.Write(str2byteArray("format binary_little_endian 1.0\n"));
            writer.Write(str2byteArray("element vertex " + pointCount + "\n"));
            writer.Write(str2byteArray("property float x\n"));
            writer.Write(str2byteArray("property float y\n"));
            writer.Write(str2byteArray("property float z\n"));
            writer.Write(str2byteArray("end_header\n"));
            //Write data
            writer.Write(pointCloudBytes);
            writer.Close();
        }
      
        private static byte[] str2byteArray(string theString) {
            return System.Text.Encoding.ASCII.GetBytes(theString);
        }
    }
}
