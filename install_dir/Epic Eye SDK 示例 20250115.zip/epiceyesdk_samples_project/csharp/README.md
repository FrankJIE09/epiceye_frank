# EpicEye SDK for C#

# How to run example
## Restore dependencies
```
cd samples/<任意一个sample工程>
dotnet restore
```

## run example
```
dotnet run
```