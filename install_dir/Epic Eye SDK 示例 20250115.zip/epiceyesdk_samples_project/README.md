# EpicEye SDK
详见各语言文件夹下的README.md
## C++
[EpicEye SDK for C++ ](cpp/README.md)
## C#
[EpicEye SDK for C#](csharp/README.md)
## Python
[EpicEye SDK for Python](python/README.md)

## EpicRaw description

### EpicRaw1

#### Header Part

```c
FileType = "EPICRAW1"         // 8 bytes, version info
width = int32                 // 4 bytes
height = int32                // 4 bytes
// 3 * 3 camera matrix, row major
camera matrix = float64 * 9   // 8 * 9 = 72 bytes, camera matrix
distortion = float64 * 5      // 8 * 5 = 40 bytes, camera distortion
    // K1  = float64
    // K2  = float64
    // P1  = float64
    // P2  = float64
    // K3  = float64
camera config                 // 4 * 7 = 28 bytes, camera configs
    // projector brightness = int32
    // exp time 2d          = float32
    // exp time 3d          = float32
    // use hdr              = bool but save as int32
    // exp time hdr         = float32
    // use PF               = bool but save as int32
    // use SF               = bool but save as int32
date type = int32             // 4 bytes
    // 0: RGB only
    // 1: depth only
    // 4: depth + RGB
depth data length = int32     // 4 bytes
image data length = int32     // 4 bytes


                              // Total: 168 bytes
```

#### Data Part

##### Depth Data = resolution * sizeof(double) = depth data length in header

##### Image Data = resolution * sizeof(uint8) * 3 (RGB) = image data length in header

### EpicRaw2

#### Header Part

```c
FileType = "EPICRAW2"         // 8 bytes, version info
width = int32                 // 4 bytes
height = int32                // 4 bytes
date type = int32             // 4 bytes
    // 0: RGB only
    // 1: depth only
    // 2: 16bit image only
    // 4: depth + RGB
    // 8: origin Fringe-Pattern images
    // 16: depth + 16bit image
camera matrix length = int32  // 4 bytes, default: 8 * 9 = 72, row major
distortion length = int32     // 4 bytes
config str length = int32     // 4 bytes
depth data length = int32     // 4 bytes
image data length = int32     // 4 bytes


                              // Total: 40 bytes
```

#### Data Part

##### Camera matrix data = 9 * sizeof(double) = camera matrix length in header

##### Distortion data = n * sizeof(double) = distortion length in header

##### Config str data (json string)

##### Depth data = resolution * sizeof(double) = depth data length in header

##### Image data = resolution * sizeof(uint8) * 3 (RGB) / resolution * 2 bytes (bitmap) = image data length in header
